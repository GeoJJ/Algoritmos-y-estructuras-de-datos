/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana3_gjja;
import java.util.Arrays;
/**
 *
 * @author LAB-USR-AREQUIPA
 */
public class Semana3_gjja {
    public static void main(String[] args) {
        int[] arreglo1 = {0, 1, 2, 3, 5};
        int[] arreglo2 = {0, 1, 3, 4, 5};
        
        System.out.println("ARREGLOS");
        System.out.println("Arreglo n�1");
        System.out.print(arreglo1[0] + "/");
        System.out.print(arreglo1[1] + "/");
        System.out.print(arreglo1[2] + "/");
        System.out.println (arreglo1[3]);
        
        System.out.println("Arreglo n�2");
        System.out.print(arreglo2[0] + "/");
        System.out.print(arreglo2[1] + "/");
        System.out.print(arreglo2[2] + "/");
        System.out.println (arreglo2[3]);
  
System.out.println(" 1. COMPARACI�N ");
        boolean[] resultadosComp = new boolean[arreglo1.length];
        for (int i = 0; i < arreglo1.length; i++) {
            resultadosComp[i] = (arreglo1[i] == arreglo2[i]);
              
            if (arreglo1[i] == arreglo2[i]) {
                System.out.println("�ndice " + i + ": " + arreglo1[i] + " vs " + arreglo2[i] + " -> " + "Son iguales");
            } else
            {
                System.out.println("�ndice " + i + ": " + arreglo1[i] + " vs " + arreglo2[i] + " -> " + "Son diferentes, deben arreglarse");
            }
        }
System.out.println(" 2. CLONACI�N ");    
        int[] clonArreglo1 = arreglo1.clone();
        clonArreglo1[0] = 12345;
        
        System.out.print(clonArreglo1);
        System.out.print(clonArreglo1[0]);
        System.out.println("Los clones no son iguales");
      
System.out.println(" 3. FUSI�N ");  
        int[] fusion = new int[arreglo1.length + arreglo2.length];

      for (int i = 0; i < arreglo1.length; i++) {
        fusion[i] = arreglo1[i];
    }

    for (int j = 0; j < arreglo2.length; j++) {
        fusion[arreglo1.length + j] = arreglo2[j];
    }
    System.out.println("Arreglo 1 + Arreglo 2");
    System.out.println(Arrays.toString(fusion));
}

}

     
        
       


